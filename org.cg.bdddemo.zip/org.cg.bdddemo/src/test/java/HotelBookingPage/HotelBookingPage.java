package HotelBookingPage;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingPage {
	@Given("^User is on SignUp page\\.$")
	public void user_is_on_SignUp_page()  {
	   
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page()  {
	 
	}

	@Given("^User is on signup page$")
	public void user_is_on_signup_page1()  {
	 
	}

	@Then("^navigate to the password generation page$")
	public void navigate_to_the_password_generation_page()  {
	
	}

	@When("^user leaves firstname$")
	public void user_leaves_firstname()  {
	
	}

	@When("^lastname as blank$")
	public void lastname_as_blank() {
	
	}

	@When("^clicks the button$")
	public void clicks_the_button()  {
	  
	}

	@Then("^display firstname And second name should not be empty$")
	public void display_firstname_And_second_name_should_not_be_empty()  {
	   
	}

	@Given("^user is on signup page$")
	public void user_is_on_signup_page()  {
	  
	}

	@When("^user enters all the data$")
	public void user_enters_all_the_data()  {
	 
	}

	@When("^user enters the incorrect email format and clicks the button$")
	public void user_enters_the_incorrect_email_format_and_clicks_the_button()  {
	  
	}

	@Then("^display email id should not be empty and enter valid email id$")
	public void display_email_id_should_not_be_empty_and_enter_valid_email_id()  {
	
	}

	@When("^user enter invalid mobile number and leave as blank$")
	public void user_enter_invalid_mobile_number_and_leave_as_blank(DataTable arg1)  {
	}

	@Then("^display alert message$")
	public void display_alert_message() {
	   
	}

	@When("^user does not select any city$")
	public void user_does_not_select_any_city()  {
	
	}

	@Then("^display that user need to select city name$")
	public void display_that_user_need_to_select_city_name()  {

	}

	@When("^user does not select any state$")
	public void user_does_not_select_any_state()  {
	   
	}

	@Given("^reenter the password and click on confirm password$")
	public void reenter_the_password_and_click_on_confirm_password()  {
	 
	}

	@When("^user doesnot enter either username or password$")
	public void user_doesnot_enter_either_username_or_password()  {
	    
	}

	@Then("^display password generated has been successfully and navigate to the login page$")
	public void display_password_generated_has_been_successfully_and_navigate_to_the_login_page()  {
	
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page1()  {
	   
	}

	@When("^clicks the Login button$")
	public void clicks_the_Login_button()  {
	    
	}

	@Then("^display appropriate message$")
	public void display_appropriate_message()  {
	 
	}

	@Given("^user is on login page$")
	public void user_is_on_login_page()  {
	 ;
	}

	@When("^user enters incorrect username or passsword$")
	public void user_enters_incorrect_username_or_passsword()  {
	 
	}

	@Then("^display login failed message$")
	public void display_login_failed_message()  {
	  
	}

	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page()  {
	   
	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1)  {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2)  {
	 
	}



}
