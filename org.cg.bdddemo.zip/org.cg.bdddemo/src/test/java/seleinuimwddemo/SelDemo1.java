package seleinuimwddemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SelDemo1 {
	
	
	public static void main(String[] args) {
		
		//Step-1:Launch empty Browser
			//WebDriver driver=new FirefoxDriver();
		System.setProperty("webdriver.chrome.driver","D:\\STS_Programs\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//Step-2:Navigate to application
		driver.get("file:///D:/STS_Programs/App/login.html");
		
		
		//Step-3:Enter UserName(find the element and perform the action)
		//driver.findElement(By.name("userName")).sendKeys("capgemini");
		//driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("capgemini");
		 WebElement username=driver.findElement(By.name("userName"));
		username.sendKeys("capgemini");
		
		//Step:4:Enter the password
		 WebElement pass=driver.findElement(By.name("userPwd"));
		pass.clear();
		pass.sendKeys("capgemini");
		 //driver.findElement(By.name("userPwd")).sendKeys("capgemini");
		
		//step-5:Hit the login button
		
		//driver.findElement(By.className("btn")).click();
		WebElement button=driver.findElement(By.className("btn"));
		//step-6:close browser
		
		//driver.close();
		
		
		
	}

}
