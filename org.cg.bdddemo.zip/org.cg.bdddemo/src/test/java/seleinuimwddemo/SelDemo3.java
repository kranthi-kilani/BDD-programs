package seleinuimwddemo;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelDemo3 {
	
	public static void main(String[] args) {

	System.setProperty("webdriver.chrome.driver","D:\\STS_Programs\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	
	
	driver.navigate().to("file:///D:/STS_Programs/App/hotelbooking.html");
	driver.findElement(By.name("txtFN")).sendKeys("capgemini");
	
	
  String actualheading=	driver.findElement(By.xpath("//h2")).getText();
	System.out.println(actualheading);
	
	String actual="Hotel Booking Form";
	if(actual.equals(actualheading)) {
		System.out.println("Heading matched");
	}else {
		System.out.println("not matched");
	}
	
	String attval=driver.findElement(By.id("txtFirstName")).getAttribute("name");
	System.out.println(attval);
	
	String attval1=driver.findElement(By.id("txtFirstName")).getAttribute("value");
	System.out.println(attval1);
	


	

}
}