package seleinuimwddemo;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Seldemo4 {

	@Test
	public void test() {
		System.setProperty("webdriver.chrome.driver","D:\\STS_Programs\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		
		//implicit wait statement
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		
		driver.navigate().to("file:///D:/STS_Programs/App/login.html");
		//driver.findElement(By.name("txtFN")).sendKeys("capgemini");
		
		 WebElement username=driver.findElement(By.name("userName"));
			username.sendKeys("capgemini");
			
			 WebElement pass=driver.findElement(By.name("userPwd"));
	
				pass.sendKeys("capgemini");
				
				WebElement button=driver.findElement(By.className("btn"));
				driver.findElement(By.className("btn")).click();
		
		//Explicit wait statement
		WebDriverWait wait=new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.alertIsPresent());
		
		Alert alert=driver.switchTo().alert();
		System.out.println(alert.getText());
		
		alert.accept();
		//alert.dismiss();
		
	}

}
