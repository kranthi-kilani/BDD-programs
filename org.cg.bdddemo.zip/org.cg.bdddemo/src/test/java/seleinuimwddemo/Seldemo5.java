package seleinuimwddemo;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Seldemo5 {

	@Test
	public void test() throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","D:\\STS_Programs\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.navigate().to("file:///D:/STS_Programs/App/hotelbooking.html");
	
		

		WebElement city = driver.findElement(By.name("city"));
		Select c=new Select(city);
		//c.selectByVisibleText("Chennai");
		c.selectByValue("Chennai");
		//c.selectByIndex(3);
		
		
		WebElement state = driver.findElement(By.name("state"));
		Select s=new Select(state);
		s.selectByIndex(2);
		//s.selectByVisibleText("Tamilnadu");
		//s.selectByValue("Tamilnadu");
		Thread.sleep(1000);
		
		s.deselectByIndex(2);
	
	}
	
	

}
