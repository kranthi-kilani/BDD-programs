package Form;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RegisterForm {
	WebDriver wd;

	
	public RegisterForm(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	public RegisterForm() {
	
	}

	@FindBy(name = "txtName")
	@CacheLookup
	WebElement name;

	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;

	@FindBy(id ="txtMobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(xpath="//textarea[@rows='5']")
	@CacheLookup
	WebElement address;
	
	@FindBy(id="male")
	@CacheLookup
	WebElement gender1;
	
	
	@FindBy(id="female")
	@CacheLookup
	WebElement gender2;
	

	@FindBy(how = How.ID, using = "btn")
	@CacheLookup
	WebElement button;



	public void setName(String Name) {
		
		name.sendKeys(Name);
	}
	public void setAddress(String Address) {
		address.sendKeys(Address);
	}
	

	public WebElement getGender1() {
		return gender1;
	}

	public void setGender1() {
		this.gender1.click();
	}

	public WebElement getGender2() {
		return gender2;
	}

	public void setGender2() {
		this.gender2.click();
	}

	public void setEmail(String emailId) {
		email.sendKeys( emailId);
	}

	public void setMobile(String mobileno) {
	mobile.sendKeys(  mobileno);
	}

	public void setButton() {
		button.click();
	}
	

	

	public WebElement getName() {
		return name;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getMobile() {
		return mobile;
	}

	public WebElement getButton() {
		return button;
	}
	public WebElement getAddress() {
		return address;
	}
	
	
	
	

}
