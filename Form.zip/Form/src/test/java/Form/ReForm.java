package Form;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReForm {

	RegisterForm reg = new RegisterForm();
	static WebDriver driver = null;

	@Given("^User is on the register form$")
	public void user_is_on_the_register_form() {
		System.setProperty("webdriver.chrome.driver", "D:\\STS_Programs\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/kkranthi/Documents/Form.html");
		reg = new RegisterForm(driver);

	}

	@When("^name is blank$")
	public void name_is_blank() throws Exception {
		reg.setName("");
		Thread.sleep(1000);
		
		
	}

	@When("^clicks on submit button$")
	public void clicks_on_submit_button() {
		reg.setButton();
	}

	@Then("^display alert message$")
	public void display_alert_message() {
		
	
	}

	@When("^user enters the valid name$")
	public void user_enters_the_valid_name() throws Exception {
		reg.setName("kranthi");
		Thread.sleep(1000);
		reg.setAddress("chennai-sipcot");
		Thread.sleep(1000);
	    reg.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		reg.setMobile("8074588603");
		Thread.sleep(1000);
		
		

	}

	@Then("^user should navigate$")
	public void user_should_navigate() throws Exception {
		reg.setButton();

	}

	@When("^Email is blank$")
	public void email_is_blank() throws InterruptedException {
		reg.setName("kranthi");
		Thread.sleep(1000);
		reg.setAddress("chennai-sipcot");
		Thread.sleep(1000);
		reg.setEmail("");
		Thread.sleep(1000);
		reg.setMobile("8074588603");
		Thread.sleep(1000);
	
	}

	@When("^clicks ont the submit button$")
	public void clicks_ont_the_submit_button() {
		reg.setButton();

	}

	@Then("^user should  navigate to the next field$")
	public void user_should_navigate_to_the_next_field() {
		

	}

	@When("^user enter wrong pattern$")
	public void user_enter_wrong_pattern(DataTable email) throws Exception {
		reg.setName("kranthi");
		Thread.sleep(1000);
		reg.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		reg.setMobile("8074588603");
		Thread.sleep(1000);
		
		List<String> list=email.asList(String.class);
		String temp=null;
		for(String emailTemp:list) {
			temp=emailTemp;
			reg.getEmail().clear();
			reg.setEmail(emailTemp);
			Thread.sleep(1000);
			reg.setButton();

			if (Pattern.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", temp)) {
	System.out.println(temp);
				System.out.println("Matching ");
			} else {
				String alert = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				
				driver.switchTo().alert().accept();
				System.out.println("not matched " + alert);
			}
		}

		reg.setButton();
	
			
		}
		
		
		

	

	@When("^user enter the incorrrect mobile no\\.$")
	public void user_enter_the_incorrrect_mobile_no(DataTable mobile) throws Exception {
		reg.setName("kranthi");
		Thread.sleep(1000);
		reg.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		reg.setMobile("8074588603");
		Thread.sleep(1000);

		List<String> list = mobile.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			reg.getMobile().clear();
			reg.setMobile(dataTemp);
			Thread.sleep(1000);
			reg.setButton();

			if (Pattern.matches("[789][0-9]{9}", data)) {
				System.out.println("Matching ");
			} else {
				String alert = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				
				driver.switchTo().alert().accept();
				System.out.println("not matched " + alert);
			}
		}

		reg.setButton();

	}

	@When("^user leaves mobile no\\. blank$")
	public void user_leaves_mobile_no_blank() throws Exception {
		reg.setMobile("");
		Thread.sleep(1000);
		reg.setButton();

	}

	@When("^user enters the valid mobile no$")
	public void user_enters_the_valid_mobile_no() throws Exception {
		reg.setName("kranthi");
		Thread.sleep(1000);
		reg.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		reg.setMobile("9090909090");
		Thread.sleep(1000);

		
	}

	@Then("^user should navigate to the next field of the form$")
	public void user_should_navigate_to_the_next_field_of_the_form() {
	reg.setAddress("chennai");

	}

}
