package HotelBooking;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingPageFactory {
	
	
	WebDriver wb;

	public HotelBookingPageFactory(WebDriver wb) {
		this.wb = wb;
		PageFactory.initElements(wb, this); 
		
		
	}

	public HotelBookingPageFactory() {
	
	}
	
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement FirstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement LastName;
	
	@FindBy(name="Email")
	@CacheLookup
	WebElement Email;
	
	@FindBy(name="Phone")
	@CacheLookup
	WebElement mobileno;
	

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement Address;
	

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	WebElement city;
	
	

	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	WebElement state;
	

	/*@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	WebElement Persons;*/
	

	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	@CacheLookup
	WebElement CardHolder;
	

	@FindBy(xpath="//*[@id=\"txtCvv\"]")
	@CacheLookup
	WebElement Cvv;
	

	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	@CacheLookup
	WebElement Debit;
	
	

	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	@CacheLookup
	WebElement Month;
	
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	@CacheLookup
	WebElement Year;


	@FindBy(how = How.ID, using = "btnPayment")
	@CacheLookup
	WebElement button;
	
	@FindBy(xpath = "//*[@id='rooms']")
	@CacheLookup
	WebElement rooms;
	
	

	@FindBy(how = How.NAME, using = "persons")
	@CacheLookup
	int persons;
	
	public void setPersons(int noOfPErsons) {
		persons = noOfPErsons;
	}
	public int getPersons() {
		return persons;
	}

	public WebElement getRooms() {
		return rooms;
	}

	

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}

	public void setFirstName(String firstName) {
		FirstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
	   LastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		Email.sendKeys(email);
	}

	public void setMobileno(String mobileno) {
	this.mobileno.sendKeys(mobileno);
	}

	public void setAddress(String address) {
      Address.sendKeys(address);
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}
/*
	public void setPersons(String persons) {
	 this.Persons.sendKeys(persons);
	}
*/
	public void setCardHolder(String cardHolder) {
		this.CardHolder.sendKeys(cardHolder);;
	}

	public void setCvv(String cvv) {
		this.Cvv.sendKeys(cvv);
	}

	public void setDebit(String debit) {
		this.Debit.sendKeys(debit);
	}

	public void setMonth(String month) {
		this.Month.sendKeys(month); 
	}

	public void setYear(String year) {
		this.Year.sendKeys(year);
	}



	public WebElement getFirstName() {
		return FirstName;
	}

	public WebElement getLastName() {
		return LastName;
	}

	public WebElement getEmail() {
		return Email;
	}

	public WebElement getMobileno() {
		return mobileno;
	}

	public WebElement getAddress() {
		return Address;
	}

	public WebElement getCity() {
		return city;
	}

	public WebElement getState() {
		return state;
	}

	/*public WebElement getPersons() {
		return Persons;
	}*/

	public WebElement getCardHolder() {
		return CardHolder;
	}

	public WebElement getCvv() {
		return Cvv;
	}

	public WebElement getDebit() {
		return Debit;
	}

	public WebElement getMonth() {
		return Month;
	}

	public WebElement getYear() {
		return Year;
	}
	
	
	
	
	
	
	
}
