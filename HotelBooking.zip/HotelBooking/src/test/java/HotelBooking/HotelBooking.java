package HotelBooking;



import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBooking {

	static WebDriver driver = null;
	HotelBookingPageFactory fact = new HotelBookingPageFactory();

	@Given("^User is on the register form$")
	public void user_is_on_the_register_form() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "D:\\STS_Programs\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///D:/STS_Programs/App/hotelbooking.html");
		fact = new HotelBookingPageFactory(driver);
	}

	@When("^FirstName is blank$")
	public void firstname_is_blank() throws Exception {
		fact.setFirstName("");
		Thread.sleep(1000);
	}

	@When("^LastName is blank$")
	public void lastname_is_blank() throws Exception {
		fact.setFirstName("kranthi");
		Thread.sleep(1000);

		fact.setLastName("");
		Thread.sleep(1000);
	}

	@When("^clicks on submit button$")
	public void clicks_on_submit_button() throws Throwable {
		fact.setButton();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	     Thread.sleep(2000);
	     
			}

	@When("^Email is blank$")
	public void email_is_blank() throws Throwable {
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("");
		Thread.sleep(1000);

	}

	@When("^clicks ont the submit button$")
	public void clicks_ont_the_submit_button() throws Throwable {
		fact.setButton();
		Thread.sleep(1000);
	}

	@When("^user leaves mobile no\\. blank$")
	public void user_leaves_mobile_no_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user slect more than three persons then no of booked rooms should change$")
	public void user_slect_more_than_three_persons_then_no_of_booked_rooms_should_change() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(1);
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);
	}

	@When("^user leaves city blank$")
	public void user_leaves_city_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user leaves state blank$")
	public void user_leaves_state_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Select State");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user leaves CardholderName blank$")
	public void user_leaves_CardholderName_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(9);
		Thread.sleep(1000);
		fact.setCardHolder("");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user leaves Debit blank$")
	public void user_leaves_Debit_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(2);
		Thread.sleep(1000);
		fact.setCardHolder("Prabhas");
		Thread.sleep(1000);
		fact.setDebit("123456789");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user leaves Cvv blank$")
	public void user_leaves_Cvv_blank() throws Exception {

		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(8);
		Thread.sleep(1000);
		fact.setCardHolder("Prabhas");
		Thread.sleep(1000);
		fact.setDebit("123456789");
		Thread.sleep(1000);
		fact.setCvv("");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);
	}

	@When("^user leaves Month blank$")
	public void user_leaves_Month_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(3);
		Thread.sleep(1000);
		fact.setCardHolder("Prabhas");
		Thread.sleep(1000);
		fact.setDebit("123456789");
		Thread.sleep(1000);
		fact.setCvv("900");
		Thread.sleep(1000);
		fact.setMonth("");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user leaves Year blank$")
	public void user_leaves_Year_blank() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(6);
		Thread.sleep(1000);
		fact.setCardHolder("Prabhas");
		Thread.sleep(1000);
		fact.setDebit("123456789");
		Thread.sleep(1000);
		fact.setCvv("900");
		Thread.sleep(1000);
		fact.setMonth("Jan");
		Thread.sleep(1000);
		fact.setYear("");
		Thread.sleep(1000);
		fact.setButton();
		Thread.sleep(1000);

	}

	@When("^user enter invalid email pattern$")
	public void user_enter_invalid_email_pattern(DataTable email) throws Exception {

		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		List<String> list = email.asList(String.class);
		String temp = null;
		for (String emailTemp : list) {
			temp = emailTemp;
			fact.getEmail().clear();
			fact.setEmail(emailTemp);
			Thread.sleep(1000);
			fact.setButton();

			if (Pattern.matches("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$", temp)) {
				System.out.println(temp);
				System.out.println("Matching ");
			} else {
				String alert = driver.switchTo().alert().getText();
				Thread.sleep(1000);

				driver.switchTo().alert().accept();
				System.out.println("not matched " + alert);
			}
		}

		fact.setButton();

	}

	@When("^user enter the incorrrect mobile no\\.$")
	public void user_enter_the_incorrrect_mobile_no(DataTable mobile) throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);

		List<String> list = mobile.asList(String.class);
		String data = null;
		for (String dataTemp : list) {
			data = dataTemp;
			fact.getMobileno().clear();
			fact.setMobileno(dataTemp);
			Thread.sleep(1000);
			fact.setButton();

			if (Pattern.matches("[789][0-9]{9}", data)) {
				System.out.println("Matching ");
			} else {
				String alert = driver.switchTo().alert().getText();
				Thread.sleep(1000);

				driver.switchTo().alert().accept();
				System.out.println("not matched " + alert);
			}
		}

		fact.setButton();

	}

	@When("^user enter all valid details$")
	public void user_enter_all_valid_details() throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(7);
		Thread.sleep(1000);
		fact.setCardHolder("Prabhas");
		Thread.sleep(1000);
		fact.setDebit("123456789");
		Thread.sleep(1000);
		fact.setCvv("900");
		Thread.sleep(1000);
		fact.setMonth("Jan");
		Thread.sleep(1000);
		fact.setYear("1990");
		Thread.sleep(1000);
	

	}

	@Then("^Display success Page$")
	public void display_success_Page() throws Exception {
	
		fact.setButton();
		Thread.sleep(1000);

	}
	@When("^User enter the valid (\\d+)$")
	public void user_enter_the_valid(Integer mobile) throws Exception {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		String mobilenumber=mobile.toString();
		fact.setMobileno(mobilenumber);
		Thread.sleep(1000);
	
	}
	@When("^user enters (\\d+)$")
	public void user_enters(int noOfPersons) throws Exception  {
		Thread.sleep(1000);
		fact.setFirstName("kranthi");
		Thread.sleep(1000);
		fact.setLastName("kilani");
		Thread.sleep(1000);
		fact.setEmail("kkranthiyadav@gmail.com");
		Thread.sleep(1000);
		fact.setMobileno("9090909090");
		Thread.sleep(1000);
		fact.setAddress("Chennai");
		Thread.sleep(1000);
		fact.setCity("Chennai");
		Thread.sleep(1000);
		fact.setState("Tamilnadu");
		Thread.sleep(1000);
		fact.setPersons(noOfPersons);
		Thread.sleep(2000);
	}

	@Then("^for (\\d+) allocate (\\d+)$")
	public void for_allocate(int guest, int rooms) {
		
		if (guest <= 3) {
			System.out.println("no of Rooms:" + rooms);
			assertEquals(1, rooms);
		} else if (guest <= 6) {
			System.out.println("no of Rooms:" + rooms);
			assertEquals(2, rooms);
		} else if (guest <= 9) {
			System.out.println("no of Rooms:" + rooms);
			assertEquals(3, rooms);
		}


	}
	
	@After
	public void close() {
		driver.close();
	}
}
